<?php
   $dbServername = "localhost";
   $dbUsername = "RuchaM";
   $dbPassword = "Techxposure2k19";
   $dbName = "techxposure";
   //connection
   $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
?>

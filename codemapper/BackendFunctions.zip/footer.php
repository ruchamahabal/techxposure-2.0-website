
<p>&#169; codemapper, 2018 </p>
<script type="text/javascript" src="vendors/js/jquery.min.js"></script>

<!--JQuery-->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<!--Bootstrap CORE JS-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- Animation JS -->
<script src="vendors/js/TweenLite.min.js"></script>
<script src="vendors/js/EasePack.min.js"></script>
<script src="vendors/js/rAF.js"></script>
<script src="vendors/js/demo-1.js"></script>

</body>
</html>

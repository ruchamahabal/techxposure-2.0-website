<?php include_once 'header.php'; ?>

<!--HERO SECTION-->
<div class="demo-1">
	<div class="content">
		<div id="large-header" class="large-header">
			<canvas id="demo-canvas"></canvas>
			<h1 class="main-title">CODE <span class="thin">MAPPER</span></h1>
		</div>
	</div>


<?php include_once 'footer.php'; ?>
 

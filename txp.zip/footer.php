<!-- Footer -->
<!-- Footer -->
	<section id="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="https://www.facebook.com/techxposure/"><i class="fab fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="https://www.youtube.com/channel/UCFa_PfH4dVvyupOmvh8QIww"><i class="fab fa-youtube"></i></a></li>
						<li class="list-inline-item"><a href="https://www.instagram.com/techxposure_2.0"><i class="fab fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="mailto:techxposuretxp@gmail.com"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				</hr>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p><h5><b>TechXposure 2.0</b> is a Techno-Cultural fest of S.K. Somaiya College of Arts, Science and Commerce</h5></p>
					<p class="h6">&copy Copyright 2018-2019 TechXposure 2.0</p>
					<p class="h6">Assets by: Om Thakkar and Akhilesh Nair</p>
          <p class="h6"><h5>Designed and Developed By: Rucha Mahabal and Shubham Parchure</h5></p>
				</div>
				</hr>
			</div>
		</div>
	</section>
  <!-- /Footer -->
    <!-- Bootstrap JS -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js\popper.min.js"></script>
    <script src="js\bootstrap.min.js"></script>
  </body>
</html>
